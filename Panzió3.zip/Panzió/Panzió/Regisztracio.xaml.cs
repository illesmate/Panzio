﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Panzió
{
    /// <summary>
    /// Interaction logic for Regisztracio.xaml
    /// </summary>
    public partial class Regisztracio : Window
    {
        public Regisztracio()
        {
            InitializeComponent();
        }

        private void elozo_Click(object sender, RoutedEventArgs e)
        {
           // panziList.Add(new Panzi(int.Parse(Szobakszama.Text), int.Parse(hely.Text), int.Parse(ar.Text)));
            //dgrracs.Items.Refresh();
            Close();
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            yes.IsChecked = yes.IsChecked;
        }
    }
}
